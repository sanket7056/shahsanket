<footer class="site-footer clearfix">
          <div class="footer-social">
            <ul class="footer-social-links">
              <li>
                <a href="https://www.linkedin.com/in/sanket-shah-47472854" target="_blank">Linkedin </a>
              </li>

              <li>
                <a href="https://www.facebook.com/Sanket7056" target="_blank">Facebook</a>
              </li>

              <li>
                <a href="https://www.instagram.com/sanket7056" target="_blank">Instagram</a>
              </li>
            </ul>
          </div>
              
          <div class="footer-copyrights">
            <p>© 2022 All rights reserved.</p>
          </div>
        </footer>