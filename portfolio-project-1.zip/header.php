<header id="site_header" class="header">
          <div class="header-content clearfix">
                
            <!-- Text Logo -->
            <div class="text-logo">
              <a href="/">
                <div class="logo-symbol">S</div>
                <div class="logo-text">Sanket <span>Shah</span></div>
              </a>
            </div>
            <!-- /Text Logo -->

            <!-- Navigation -->
            <div class="site-nav mobile-menu-hide">
              <ul class="leven-classic-menu site-main-menu">
                <!-- <li class="menu-item menu-item-has-children current-menu-item">
                  <a href="index-2.html">About Me</a>
                  <ul class="sub-menu">
                    <li class="menu-item current-menu-item">
                      <a href="index-2.html">About Me 1</a>
                    </li>
                    <li class="menu-item">
                      <a href="index-3.html">About Me 2</a>
                    </li>
                  </ul>
                </li> -->

                <li class="menu-item">
                  <a href="resume.php">Resume</a>
                </li>

                <!-- <li class="menu-item menu-item-has-children">
                  <a href="portfolio.html">Portfolio</a>
                  <ul class="sub-menu">
                    <li class="menu-item">
                      <a href="portfolio-2-columns.html">Portfolio 2 Columns</a>
                    </li>
                    <li class="menu-item">
                      <a href="portfolio.html">Portfolio 3 Columns</a>
                    </li>
                    <li class="menu-item">
                      <a href="portfolio-4-columns.html">Portfolio 4 Columns</a>
                    </li>
                    <li class="menu-item">
                      <a href="portfolio-5-columns.html">Portfolio 5 Columns</a>
                    </li>
                  </ul>
                </li> -->
                
                <!-- <li class="menu-item menu-item-has-children">
                  <a href="blog.html">Blog</a>
                  <ul class="sub-menu">
                    <li class="menu-item">
                      <a href="blog.html">Blog 2 Columns</a>
                    </li>
                    <li class="menu-item">
                      <a href="blog-3-columns.html">Blog 3 Columns</a>
                    </li>
                  </ul>
                </li> -->

                <li class="menu-item">
                  <a href="contact.php">Contact</a>
                </li>
              </ul>
            </div>

            <!-- Mobile Menu Toggle -->
            <a class="menu-toggle mobile-visible">
              <i class="fa fa-bars"></i>
            </a>
            <!-- Mobile Menu Toggle -->
          </div>
        </header>